export class Movie {
    Title: string;
    imdbRating: string;
    Year: string; }
